﻿=== osu Cursor Set ===

By: M9ICH

Download: http://www.rw-designer.com/cursor-set/osu-2

Author's description:

The site from which I made cursors: https://osuskinner.com/interface/cursor?p=1. 

Everything is very simple. There is a Realworld cursor editor. You can download it from this site and there is a function to make a cursor from a picture.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.